## 📜 Living Roadmap
La roadmap aggiornata è disponibile in [`docs/ROADMAP.md`](docs/ROADMAP.md) (esportata dal Canvas).
